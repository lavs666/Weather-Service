const express = require('express');
const axios = require('axios');
require('dotenv').config();
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

// Optional: Define a default route to serve the index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/weather', async (req, res) => {
    const city = req.query.city;
    if (!city) {
        return res.status(400).json({ error: 'City is required' });
    }

    try {
        const response = await axios.get(`http://api.weatherstack.com/current`, {
            params: {
                access_key: process.env.WEATHERSTACK_API_KEY,
                query: city
            }
        });

        const data = response.data;
        if (data.error) {
            return res.status(404).json({ error: 'City not found' });
        }

        res.json({
            location: data.location.name,
            temperature: data.current.temperature,
            weather_descriptions: data.current.weather_descriptions[0],
            wind_speed: data.current.wind_speed,
            wind_dir: data.current.wind_dir,
            humidity: data.current.humidity,
            feelslike: data.current.feelslike,
        });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch weather data' });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
